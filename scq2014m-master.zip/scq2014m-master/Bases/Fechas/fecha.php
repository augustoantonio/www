<?php
echo date("\H\o\y \\e\s l\, 
		z \d\i\a\s \d\\e\l \a\�\o Y\,
		\s\\e\m\a\\n\a W\, F\, \d\i\a j");

